package com.mycompany.bonusmodule;

import java.util.*;

public class Bonus {
    private static final double BONUS_PADRAO = 2000;
    private static final double BONUS_REDUZIDO = 1000;
    private static final double LIMITE_SALARIO = 150000;

    public static int calcularBonus(List<Funcionario> funcionarios, List<Departamento> departamentos) throws BonusException {
        // Verificar se as tabelas estão vazias
        if (funcionarios.isEmpty() || departamentos.isEmpty()) {
            throw new BonusException(1); // Código 1: Tabela vazia
        }

        // Encontrar o(s) departamento(s) com maior valor de vendas
        double maiorVenda = departamentos.stream()
                .mapToDouble(departamento -> departamento.valorVendas)
                .max().orElseThrow(() -> new BonusException(1)); // Se não houver departamentos

        List<Integer> departamentosComMaiorVenda = new ArrayList<>();
        for (Departamento d : departamentos) {
            if (d.valorVendas == maiorVenda) {
                departamentosComMaiorVenda.add(d.id);
            }
        }

        // Filtrar funcionários que pertencem aos departamentos de maior venda
        List<Funcionario> funcionariosElegiveis = new ArrayList<>();
        for (Funcionario f : funcionarios) {
            if (departamentosComMaiorVenda.contains(f.departamentoId)) {
                funcionariosElegiveis.add(f);
            }
        }

        if (funcionariosElegiveis.isEmpty()) {
            throw new BonusException(2); // Código 2: Nenhum funcionário elegível
        }

        // Aplicar bônus de acordo com as regras de negócio
        for (Funcionario f : funcionariosElegiveis) {
            if ("Gerente".equalsIgnoreCase(f.cargo) || f.salario >= LIMITE_SALARIO) {
                f.aplicarBonus(BONUS_REDUZIDO); // Gerentes e salários >= 150.000
            } else {
                f.aplicarBonus(BONUS_PADRAO);
            }
        }

        return 0; // Execução bem-sucedida
    }

    public static void main(String[] args) {
        try {
            // Exemplo de dados
            List<Funcionario> funcionarios = Arrays.asList(
                new Funcionario(1, 100000, "Engenheiro", 1),
                new Funcionario(2, 160000, "Gerente", 2),
                new Funcionario(3, 120000, "Analista", 1),
                new Funcionario(4, 130000, "Gerente", 3)
            );

            List<Departamento> departamentos = Arrays.asList(
                new Departamento(1, 50000),
                new Departamento(2, 50000),
                new Departamento(3, 30000)
            );

            // Chamar o método para calcular os bônus
            int resultado = calcularBonus(funcionarios, departamentos);
            System.out.println("Resultado: " + resultado);

            // Imprimir os salários após o bônus
            for (Funcionario f : funcionarios) {
                System.out.println("Funcionario " + f.id + " novo salario: " + f.salario);
            }
        } catch (BonusException e) {
            System.out.println("Erro: Codigo " + e.getCodigo());
        }
    }
}
