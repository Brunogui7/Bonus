package com.mycompany.bonusmodule;

public class Departamento {
    int id;
    double valorVendas;

    public Departamento(int id, double valorVendas) {
        this.id = id;
        this.valorVendas = valorVendas;
    }
}
