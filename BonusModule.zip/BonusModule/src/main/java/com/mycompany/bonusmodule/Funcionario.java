package com.mycompany.bonusmodule;

public class Funcionario {
    int id;
    double salario;
    String cargo;
    int departamentoId;

    public Funcionario(int id, double salario, String cargo, int departamentoId) {
        this.id = id;
        this.salario = salario;
        this.cargo = cargo;
        this.departamentoId = departamentoId;
    }

    public void aplicarBonus(double bonus) {
        this.salario += bonus;
    }
}
