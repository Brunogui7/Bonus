/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bonusmodule;

/**
 *
 * @author bruno
 */
public class BonusModule {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
