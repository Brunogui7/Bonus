package com.mycompany.bonus;

import java.util.*;

class Funcionario {
    int id;
    double salario;
    String cargo;
    int departamentoId;

    public Funcionario(int id, double salario, String cargo, int departamentoId) {
        this.id = id;
        this.salario = salario;
        this.cargo = cargo;
        this.departamentoId = departamentoId;
    }

    public void aplicarBonus(double bonus) {
        this.salario += bonus;
    }
}

class Departamento {
    int id;
    double valorVendas;

    public Departamento(int id, double valorVendas) {
        this.id = id;
        this.valorVendas = valorVendas;
    }
}

class BonusException extends Exception {
    int codigo;

    public BonusException(int codigo) {
        this.codigo = codigo;
    }

    public int getCodigo() {
        return codigo;
    }
}

