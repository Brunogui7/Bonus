package com.mycompany.bonusmodule;

public class BonusException extends Exception {
    int codigo;

    public BonusException(int codigo) {
        this.codigo = codigo;
    }

    public int getCodigo() {
        return codigo;
    }
}
